
import SwiftUI

struct ContentView: View {
    @State var userName = ""
    @State var myPass = ""
    @State  var backgroundColor = Color.white
    var body: some View {
        VStack {
            Text("Welcom")
            TextField("UserName", text: $userName)
                .textFieldStyle(.roundedBorder)
                .padding()
            SecureField(/*@START_MENU_TOKEN@*//*@PLACEHOLDER=Label@*/"Password"/*@END_MENU_TOKEN@*/, text: $myPass)
                .textFieldStyle(.roundedBorder)
                .padding()
            Button("Log in") {
                
                if userName == "A" && myPass == "123"{
                    Text("Logged in successfully")
                    backgroundColor = Color.green
                    
                }
                else{
                    Text("UserName or password worng")
                    backgroundColor = Color.red
                }
            }
        }.frame(maxWidth: .infinity,maxHeight: .infinity).background(backgroundColor).ignoresSafeArea(.all)
     .padding()
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
