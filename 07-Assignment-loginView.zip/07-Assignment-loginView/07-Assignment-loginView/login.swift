//
//  login.swift
//  07-Assignment-loginView
//
//  Created by سرّاء. on 24/06/1444 AH.
//

import SwiftUI

struct login: View {
    var body: some View {
        ZStack {
            Image("pink")
           
                
            VStack {
                VStack{
                    Text("Login seccussfully")
                        .font(.largeTitle)
                        .padding(.bottom, 40)
                    Image("yahoo")
                        .resizable()
                        .frame(width: 300, height: 300)
                } .padding(.bottom , 100)
             
                
                
     
                
                
            }
        }
    }
}

struct login_Previews: PreviewProvider {
    static var previews: some View {
        login()
    }
}
