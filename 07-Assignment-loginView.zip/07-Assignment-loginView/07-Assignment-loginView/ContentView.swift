//
//  ContentView.swift
//  07-Assignment-loginView
//
//  Created by سرّاء. on 24/06/1444 AH.
//

import SwiftUI

struct ContentView: View {
    @State var name = ""
    @State var pass = ""
    @State var isSellected = false
    @State private var failed_msg = ""
    var body: some View {
        
        ZStack {
            Image("pink")
            
            VStack {
                if isSellected {
                    login()
                } else {
                    Image(systemName: "person.circle")
                        .resizable()
                        .frame(width: 100, height: 100)
                        .padding(.bottom , 100)
                    
                    
                    //                    Text("Enter User Name")
                    TextField("Enter your User Name", text: $name)
                        .frame(maxWidth: 180 ,maxHeight: 30)
                    Rectangle()
                        .frame(width: 280 ,height: 1)
                        .foregroundColor(.gray)
                        .padding(.bottom)
                    //                    Text("Enter Password")
                    SecureField("Enter your password", text: $pass)
                        .frame(maxWidth: 180 ,maxHeight: 30)
                    Rectangle()
                        .frame(width: 280 ,height: 1)
                        .foregroundColor(.gray)
                    
                }
                
                Text(failed_msg)
                    .font(.title3)
                   
                
                Button {

                    
                    if name == "Sarraa" && pass == "1234" {
                        isSellected.toggle()
                        failed_msg = ""
                    } else {
                        failed_msg = "The user name or the password is incorrect"
                    }
                } label: {
                    Text("Login")
                }
                .frame(width: 200, height: 40)
                .background(Color.white)
                .cornerRadius(12)
                .foregroundColor(.gray)
                .padding()
                
                
            }
        }
        
        
        
        
        
    }
    
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
