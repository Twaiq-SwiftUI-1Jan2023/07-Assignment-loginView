//
//  _7_Assignment_loginViewApp.swift
//  07-Assignment-loginView
//
//  Created by سرّاء. on 24/06/1444 AH.
//

import SwiftUI

@main
struct _7_Assignment_loginViewApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
